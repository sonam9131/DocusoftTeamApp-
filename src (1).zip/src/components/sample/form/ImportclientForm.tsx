// import { Container } from '@mui/material'
import React, { useContext, useEffect, useState } from "react";
// import { Col } from 'react-bootstrap'
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Autocomplete,
  Button,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  Switch,
  TextField,
  Box,
  Paper,
  Grid,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Typography,

} from "@mui/material";
import CallApi, { CallApiphp } from "../Services/Apicall";
import { ExpandMore } from "@mui/icons-material";
import Member from "../../Member";
import { useData } from "@microsoft/teamsfx-react";
import { TeamsFxContext } from "../../Context";
import { app } from "@microsoft/teams-js";
let folderData: any;
let clientData: any;
let clientName: any;
let agrno: any = localStorage.getItem("agrno");
let email: any = localStorage.getItem("email");
let password: any = localStorage.getItem("pass");
let intUserid: any = localStorage.getItem("intUserId");
export default function ImportclientForm() {
  const [tabs, setTabs] = useState<any>([]);
  const [expanded1, setExpanded1] = useState<string | false>(false);
  const [advancedSettingChecked, setAdvancedSettingChecked] = useState(true);
  const [channels1true, setChannels1true] = useState<any>(false);
  const [folders, setFolders] = useState([]); // State to hold folders data
  const [bussiness, setBussiness] = useState([]); // State to hold folders data
  const [selectedFolderID, setSelectedFolderID] = useState<number | null>(null);
  const [selectedBussId, setSelectedBussId] = useState<number | null>(null);
  const [expanded, setExpanded] = useState<string | false>(false);
  const [teams, setTeams] = useState([]);
  const [value, setValue] = useState<any>(null);
  const [template, setTemplate] = useState<any>(null);
  const [templateData, setTemplateData] = useState<any>(null);
  const [channels, setChannels] = useState([]);
  const [getclientid, setGetclientid] = useState("");
  const [memberuser, setMemberuser] = useState([]);
  const [getprojectid, setGetprojectid] = useState("");
  const [channelSettings, setChannelSettings] = useState({
    allowCreateUpdateChannels: false,
    allowDeleteChannels: false,
    allowAddRemoveApps: false,
    allowCreateUpdateRemoveTabs: false,
    allowCreateUpdateRemoveConnectors: false,
    allowCreateUpdateChannelsGuest: false,
    allowDeleteChannelsGuest: false,
    allowDeleteChannelsFun: false,
    allowStickersAndMemesFun: false,
    allowCustomMemesFun: false,
    allowUserEditMessages: false,
    allowUserDeleteMessages: false,
    allowOwnerDeleteMessages: false,
    allowTeamMentions: false,
    allowChannelMentions: false,
    showInTeamsSearchAndSuggestions: false,
  });
  const [userDetail, setUserDetail] = useState({
    CHnumber: "",
    Clientname: "",
    Clientid: "",
    Mobile: "",
    Telephone: "",
    Line1: "",
    Line2: "",
    Line3: "",
    Town: "",
    MCounty: "",
    Postcode: "",
    BilLine1: "",
    BilLine2: "",
    BilLine3: "",
    BilTown: "",
    BilCountry: "",
    BilPostcode: "",
    regLine1: "",
    regLine2: "",
    regLine3: "",
    regTown: "",
    regCountry: "",
    regPostcode: "",
    Selectclient: "",
    Selectteamsa: "",
    addDetails: "",
    mainAddress: "",
    biliAddress: "",
    regAddress: "",
    fullAddress: "",
    Bussiness: "",
    Status: "",
    Source: "",
    Manager: "",
  });
  const handleChannelSettingChange = (event: any) => {
    const { name, checked } = event.target;
    setChannelSettings((prevSettings) => ({
      ...prevSettings,
      [name]: checked,
    }));
  };
  const handleAdvancedSettingChange = (event: any) => {
    setAdvancedSettingChecked(event.target.checked);
  };
  const Json_GetFolders = () => {
    let passdata: any = localStorage.getItem("pass");
    let requestBody = {
      agrno: localStorage.getItem("agrno"),
      Email: localStorage.getItem("email"),
      password: passdata,
    };

    CallApi(requestBody, "Json_GetFolders", function (res: any) {
      if (res) {
        console.log(res, "response11");
        let str = JSON.parse(JSON.stringify(res));
        let json = JSON.parse(str.d);
        // folderData = json.Table
        // console.log(folderData,"foldersfolders");
        setFolders(json.Table);
        console.log(folders, "foldersfolders");
      } else {
        // Handle error if needed
      }
    });
  };
  const onChangeclientlist = (
    event: React.ChangeEvent<{}>,
    value: FolderList | null
  ) => {
    event.preventDefault();
    if (value) {
      // Update the selectedFolderID state with the FolderID of the selected option
      folderData = value.FolderID;
      Json_GetClientsByFolder(folderData);
      setSelectedFolderID(value.FolderID);
      console.log(value.FolderID, "FolderID", selectedFolderID);
    } else {
      // If no option is selected, clear the selectedFolderID state
      setSelectedFolderID(null);
    }
  };
  const Json_GetClientsByFolder = (projectId: any) => {
    let passdata: any = localStorage.getItem("pass");
    let requestBody = {
      agrno: localStorage.getItem("agrno"),
      Email: localStorage.getItem("email"),
      password: passdata,
      ProjectId: projectId,
    };
    CallApi(requestBody, "Json_GetCCodeClientsByFolder", function (res: any) {
      if (res) {
        console.log(res, "Json_GetCCodeClientsByFolder");
        let str = JSON.parse(JSON.stringify(res));
        let json = JSON.parse(str.d);
        const filteredData = json.Table.filter((item: any) => !item.MTeamId);

        console.log(json.Table, "Getclientbyfolder", filteredData);

        setBussiness(filteredData);
      } else {
      }
    });
  };
  const defaultProps = {
    options: teams,
    getOptionLabel: (option: FilmOptionType) => option.Name || "",
  };
  const onChangeTeams = (
    event: React.ChangeEvent<{}>,
    value: FilmOptionType | null
  ) => {
    event.preventDefault();
    if (value) {
      setValue(value.TemplateId ? value.TemplateId : "");
      console.log(value, "SourceIdiiioioioi");
      getMSTeamsTemplatesDetailsById(value.TemplateId);
    } else {
      // If no option is selected, clear the selectedFolderID state
      setValue(null);
    }
  };
  const getMSTeamsTemplatesList = () => {
    let requestBody = {
      agrno: agrno,
      strEmail: email,
      password: password,
    };

    CallApiphp(requestBody, "getMSTeamsTemplatesList", function (res: any) {
      if (res) {
        console.log(res, "getMSTeamsTemplatesList");
        setTeams(res.data);
      } else {
      }
    });
  };
  const getAccessToken = () => {
    let request = {
      "clientId": "f4dd7cc3-897d-46dc-88a8-fe9c3057445d",
      "clientSecret": ".Kw8Q~FaUstqfCpCmUsQQju-r6r.h5HJMmEk4bXe",
      "tenantId": "65180896-6dc7-405c-9ec1-3839e91ae948"
    }
    CallApiphp(request, "getAccessToken", function (res: any) {
      if (res) {
        console.log(res.token, "getAccessToken");
        // getUsersMSTeam(res.token);
        setTemplateData(res.token);
      } else {
      }
    });
  }
  const getMSTeamsTemplatesDetailsById = (templateId: any) => {
    let requestBody = {
      agrno: agrno,
      strEmail: email,
      password: password,
      TemplateId: templateId,
    };

    CallApiphp(
      requestBody,
      "getMSTeamsTemplatesDetailsById",
      function (res: any) {
        if (res) {
          console.log(
            JSON.parse(res.data[0].TemplateData),
            "getMSTeamsTemplatesDetailsById",
            res
          );
          let jsondata = res.data[0];
          let templatesettings = JSON.parse(jsondata.TemplateSettings);
          console.log(templatesettings, "templatesettings");
          // setTemplatesettings(templateSettings);
          if (templatesettings) {
            setChannelSettings((prevUserDetail) => ({
              ...prevUserDetail,
              allowCreateUpdateChannels:
                templatesettings.memberSettings.allowCreateUpdateChannels,
              allowDeleteChannels:
                templatesettings.memberSettings.allowDeleteChannels,
              allowAddRemoveApps:
                templatesettings.memberSettings.allowAddRemoveApps,
              allowCreateUpdateRemoveTabs:
                templatesettings.memberSettings.allowCreateUpdateRemoveTabs,
              allowCreateUpdateRemoveConnectors:
                templatesettings.memberSettings
                  .allowCreateUpdateRemoveConnectors,
              allowCreateUpdateChannelsGuest:
                templatesettings.guestSettings.allowCreateUpdateChannelsGuest,
              allowDeleteChannelsGuest:
                templatesettings.guestSettings.allowDeleteChannelsGuest,
              allowDeleteChannelsFun:
                templatesettings.funSettings.allowDeleteChannelsFun,
              allowStickersAndMemesFun:
                templatesettings.funSettings.allowStickersAndMemesFun,
              allowCustomMemesFun:
                templatesettings.funSettings.allowCustomMemesFun,
              allowUserEditMessages:
                templatesettings.messagingSettings.allowUserEditMessages,
              allowUserDeleteMessages:
                templatesettings.messagingSettings.allowUserDeleteMessages,
              allowOwnerDeleteMessages:
                templatesettings.messagingSettings.allowOwnerDeleteMessages,
              allowTeamMentions:
                templatesettings.messagingSettings.allowTeamMentions,
              allowChannelMentions:
                templatesettings.messagingSettings.allowChannelMentions,
              showInTeamsSearchAndSuggestions:
                templatesettings.discoverySettings
                  .showInTeamsSearchAndSuggestions,
            }));
          }
          let json = JSON.parse(jsondata.TemplateData);
          console.log(json, "jsondata");
          setTemplate(json);
        } else {
        }
      }
    );
  };
  const { teamsUserCredential } = useContext(TeamsFxContext);
  const { loading, data, error } = useData(async () => {
    if (teamsUserCredential) {
      const userInfo = await teamsUserCredential.getUserInfo();
      return userInfo;
    }
  });
  const userName = loading || error ? "" : data!.displayName;
  const hubName = useData(async () => {
    await app.initialize();
    const context = await app.getContext();
    return context.app.host.name;
  })?.data;
  const userNameData: any = loading || error ? "" : data;
  console.log(memberuser, "memberusermemberuser");
  const createDefaultTeam = () => {
    let agrno: any = localStorage.getItem("agrno");
    let email: any = localStorage.getItem("email");
    let password: any = localStorage.getItem("pass");
    let projectId: any = localStorage.getItem("projectid");
    let templatedata: any = {
      "template@odata.bind":
        "https://graph.microsoft.com/v1.0/teamsTemplates/standard",
      visibility: "Private",
      displayName: clientData,
      description: "Docusoft related data with documents and apps.",
      members: [
        {
          "@odata.type": "#microsoft.graph.aadUserConversationMember",
          "roles": [
            "owner"
          ],
          "user@odata.bind": `https://graph.microsoft.com/v1.0/users/${userNameData.objectId}`
        }
      ],
      channels: channels,
      memberSettings: {
        allowCreateUpdateChannels: channelSettings.allowCreateUpdateChannels,
        allowDeleteChannels: channelSettings.allowDeleteChannels,
        allowAddRemoveApps: channelSettings.allowAddRemoveApps,
        allowCreateUpdateRemoveTabs: channelSettings.allowCreateUpdateRemoveTabs,
        allowCreateUpdateRemoveConnectors: channelSettings.allowCreateUpdateRemoveConnectors,
        "TeamMember.ReadWriteNonOwnerRole.All": true,
        "TeamMember.ReadWrite.All": true
      },
      guestSettings: {
        allowCreateUpdateChannels: channelSettings.allowCreateUpdateChannels,
        allowDeleteChannels: channelSettings.allowDeleteChannels
      },
      funSettings: {
        allowGiphy: channelSettings.allowDeleteChannelsFun,
        giphyContentRating: "Moderate",
        allowStickersAndMemes: channelSettings.allowStickersAndMemesFun,
        allowCustomMemes: channelSettings.allowCustomMemesFun
      },
      messagingSettings: {
        allowUserEditMessages: channelSettings.allowUserEditMessages,
        allowUserDeleteMessages: channelSettings.allowUserDeleteMessages,
        allowOwnerDeleteMessages: channelSettings.allowOwnerDeleteMessages,
        allowTeamMentions: channelSettings.allowTeamMentions,
        allowChannelMentions: channelSettings.allowChannelMentions,
      },
      discoverySettings: {
        showInTeamsSearchAndSuggestions: channelSettings.showInTeamsSearchAndSuggestions
      },
    };
    let memberdata = memberuser;
    let clienttestObj = {
      agrno: agrno,
      Email: email,
      password: password,
      clientId: clientData ? clientData : "",
      displayName: clientName ? clientName : "",
      description: "Docusoft related data with documents and apps.",
      projectId: folderData ? folderData : "",
      TemplateData: [templatedata],
      MembersData: memberdata,
      tenantId: userNameData.tenantId,
      accessToken: templateData,
    };
    console.log("getDomian");
    CallApiphp(clienttestObj, "createDefaultTeam", function (res: any) {
      if (res) {
        console.log(res, "response11");
      } else {
      }
    });
  };
  // const createDefaultTeam = () => {
  //   let passdata: any = localStorage.getItem("pass");
  //   let requestBody = {
  //     agrno: localStorage.getItem("agrno"),
  //     Email: localStorage.getItem("email"),
  //     password: passdata,
  //     clientId: clientData ? clientData : "",
  //     displayName: clientName ? clientName : "",
  //     description: "Docusoft related data with documents and apps.",
  //     projectId: folderData ? folderData : "",
  //   };
  //   console.log("getDomian");
  //   CallApiphp(requestBody, "createDefaultTeam", function (res: any) {
  //     if (res) {
  //       console.log(res, "response11");
  //     } else {
  //     }
  //   });
  // };
  const handleSubmit = (event: any) => {
    event.preventDefault();
    createDefaultTeam();
  };
  const onChangeProject = (e: any) => {
    setGetprojectid(e.target.value);
  };
  const onChangeClient = (e: any) => {
    setGetclientid(e.target.value);
  };
  const handleChangeTabs = (
    event: React.ChangeEvent<HTMLInputElement>,
    index: any
  ) => {
    const isChecked = event.target.checked;
    console.log(isChecked, "isChecked", template);
    setChannels1true(event.target.checked);
    const newChannels: any = [...channels];
    let newTabs: any = [...tabs];
    console.log(channels, "channelschannels");
    // Create a new tab object structure
    var Objt = {
      agrno: agrno,
      email: email,
      password: password,
    };

    console.log("dataStringdataString", window.btoa(JSON.stringify(Objt)));
    const newTab = {
      "teamsApp@odata.bind":
        "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps('com.microsoft.teamspace.tab.web')",
      displayName: event.target.name,
      configuration: {
        contentUrl: `${template[0].tabs[0].configuration.contentUrl}?clientID=${userDetail.Clientid
          }&projectID=${selectedFolderID}&Token=${window.btoa(
            JSON.stringify(Objt)
          )}`,
      },
    };
    console.log(newTab, "newTabdata");
    if (isChecked) {
      // Add the new tab object to the tabs array
      newTabs.push(newTab);
    } else {
      // Remove the tab object from the tabs array if the checkbox is unchecked
      const tabIndex = newTabs.findIndex(
        (tab: any) => tab.displayName === event.target.name
      );
      if (tabIndex !== -1) {
        newTabs.splice(tabIndex, 1);
      }
    }

    // Update the channels array with tabs information
    newChannels[index] = {
      ...newChannels[index],
      displayName: template[0].displayName,
      isFavoriteByDefault: template[0].isFavoriteByDefault,
      description: template[0].description,
      tabs: newTabs, // Set tabs to newTabs array
    };

    // Update state
    setTabs(newTabs);
    setChannels(newChannels);
    console.log(newChannels, "newChannelstabsonam", newTabs);
  };
  useEffect(() => {

    getAccessToken();
  }, []);
  const Json_GetConfiguration = () => {
    let passdata: any = localStorage.getItem("pass");
    let requestBody = {
      agrno: localStorage.getItem("agrno"),
      Email: localStorage.getItem("email"),
      password: passdata,
    };

    CallApi(requestBody, "Json_GetConfiguration", function (res: any) {
      if (res) {
        console.log(res, "Json_GetConfiguration");
        let str = JSON.parse(JSON.stringify(res));
        let json = JSON.parse(str.d);
        console.log(json, "Json_GetConfiguration1");
        setBussiness(json.Table1);
      } else {
        // Handle error if needed
      }
    });
  };
  useEffect(() => {
    Json_GetFolders();
    Json_GetConfiguration();
    getMSTeamsTemplatesList();
  }, []);
  const handleChangeaccord =
    (panel: string) => (_event: React.ChangeEvent<{}>, isExpanded: boolean) => {
      setExpanded1(isExpanded ? panel : false);
    };
  const onChangebussines = (
    event: React.ChangeEvent<{}>,
    value: BussinessList | null
  ) => {
    event.preventDefault();
    if (value) {
      // Update the selectedFolderID state with the FolderID of the selected option
      //   bussinessData = value.BussId;
      clientData = value.ClientID;
      clientName = value.Client;
      setSelectedBussId(value.ClientID);
      console.log(value.ClientID, "ClientID", selectedBussId);
    } else {
      // If no option is selected, clear the selectedFolderID state
      setSelectedBussId(null);
    }
  };
  const clientlist = {
    options: folders,
    getOptionLabel: (option: FolderList) => option.Folder || "",
  };
  const bussinesslist = {
    options: bussiness,
    getOptionLabel: (option: BussinessList) => option.Client || "",
  };
  const handleChange =
    (panel: string) => (_event: React.ChangeEvent<{}>, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

  // stepper
  const [activeStep, setActiveStep] = React.useState(0);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };


  const steps = [
    {
      label: 'Import Client',
      description:
        <div style={{ marginBottom: "20px" }}>
          <Grid container spacing={3}>
            <Grid item xs={6} md={6}>
              <Autocomplete
                {...clientlist}
                id="clientlist"
                clearOnEscape
                onChange={onChangeclientlist}
                renderInput={(params) => (


                  <TextField
                    {...params}
                    variant="outlined"
                    name="Selectclient"
                    value={""}
                    //   onChange={onChange}
                    label="Folder List"
                  />
                )}
              />
            </Grid>

            <Grid item xs={6} md={6}>
              <Autocomplete
                {...bussinesslist}
                id="clear-on-escape-teams"
                clearOnEscape
                onChange={onChangebussines}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    name="Selectteamsa"
                    value={""}
                    //   onChange={onChangebussines}
                    label="Reference List"
                    variant="outlined"
                  />
                )}
              />
            </Grid>

          </Grid>
        </div>,
    },

    {
      label: 'Members Data',
      description:
        <Box className='mb-4'>
          {/* <h6>Members Data</h6> */}
          <Member setMemberuser={setMemberuser} />
        </Box>
    },

    {
      label: 'Teams Setting',
      description:
        <Box>
          <div style={{ marginBottom: "20px" }}>
            <FormControl fullWidth variant="outlined">
              {/* <InputLabel id="demo-simple-select-standard-label">Age</InputLabel> */}

              <Autocomplete
                {...defaultProps}
                id="clear-on-escape-teams"
                //value={value}
                onChange={onChangeTeams}
                clearOnEscape
                renderInput={(params) => (
                  <TextField
                    {...params}
                    name="Selectteamsa"
                    label="Teams Setting"
                    variant="outlined"
                  />
                )}
              />
            </FormControl>
          </div>
          {template &&
            template.map((item: any, i: any) => (
              <div key={i}>
                <h6>{item?.displayName}</h6>
                <div style={{ marginBottom: "20px" }}></div>

                <div style={{ marginBottom: "20px" }}>
                  <FormLabel component="legend">Channel Tab</FormLabel>
                  {template &&
                    template.map((item: any, i: any) => {
                      // Assuming tabs is an array containing tab objects
                      const tabs = item.tabs;

                      // Iterate over tabs in pairs
                      for (let j = 0; j < tabs.length; j += 2) {
                        // Get two tabs at a time
                        const tab1 = tabs[j];
                        const tab2 = tabs[j + 1];

                        return (
                          <div key={j}>
                            {" "}
                            {/* Make sure to assign a unique key */}
                            {tab1 && (
                              <FormControlLabel
                                control={
                                  <Switch
                                    checked={channels1true}
                                    onChange={(e) => handleChangeTabs(e, j)}
                                    name={tab1.displayName}
                                  />
                                }
                                label={tab1.displayName}
                              />
                            )}
                            {tab2 && (
                              <FormControlLabel
                                control={
                                  <Switch
                                    checked={channels1true}
                                    onChange={(e) =>
                                      handleChangeTabs(e, j + 1)
                                    }
                                    name={tab2.displayName}
                                  />
                                }
                                label={tab2.displayName}
                              />
                            )}
                          </div>
                        );
                      }
                    })}
                </div>
                {channels1true && ( // If the switch is checked, render the TextField components
                  <>
                    <Grid container spacing={3}>
                      <Grid item xs={6} md={6}>
                        <div style={{ marginBottom: "20px" }}>
                          <TextField
                            fullWidth
                            disabled
                            id="standard-basic-client"
                            label="Project ID"
                            variant="filled"
                            name="ProjectID"
                            // value={getprojectid}
                            value={selectedFolderID}
                            onChange={onChangeProject}
                          />
                        </div>
                      </Grid>

                      <Grid item xs={6} md={6}>
                        <div style={{ marginBottom: "20px" }}>
                          <TextField
                            fullWidth
                            disabled
                            id="standard-basic-id"
                            label="Client ID"
                            variant="filled"
                            name="ClientID"
                            // value={getclientid}
                            value={clientName}
                            onChange={onChangeClient}
                          />
                        </div>
                      </Grid>
                    </Grid>
                  </>
                )}
              </div>
            ))
          }

          {/* {test setting data start here} */}
          <div style={{ marginBottom: "20px" }}>

            {/* <div style={{ marginBottom: "20px" }}>
              <Accordion
                expanded={expanded1 === "panel2dats"}
                onChange={handleChangeaccord("panel2dats")}
              >

                <AccordionSummary
                  expandIcon={<ExpandMore />}
                  aria-controls="panel2dats-content"
                  id="panel2dats-header"
                >
                  <h6>Members Data</h6>
                </AccordionSummary>
                <AccordionDetails>
                  <Member setMemberuser={setMemberuser} />
                </AccordionDetails>
              </Accordion>
            </div> */}

            <h6>Advanced Setting</h6>
            <FormGroup>
              <FormControlLabel
                control={
                  <Switch
                    checked={advancedSettingChecked}
                    onChange={handleAdvancedSettingChange}
                  />
                }
                label="Use Default"
              />
              {/* <FormControlLabel
                      control={<Switch defaultChecked />}
                      label="Use Default"
                    /> */}
            </FormGroup>
            {!advancedSettingChecked && (
              <Box className="mt-4">
                <Box className='row'>
                  <Box className='col-xl-4 col-md-4 col-sm-6 d-flex'>
                    <Box className="advance-setting-box">
                      <h6>Member Setting </h6>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={
                              channelSettings.allowCreateUpdateChannels
                            }
                            onChange={handleChannelSettingChange}
                            name="allowCreateUpdateChannels"
                          />
                        }
                        label="allowCreateUpdateChannels"
                      />
                      <FormControlLabel
                        control={
                          <Switch
                            checked={channelSettings.allowDeleteChannels}
                            onChange={handleChannelSettingChange}
                            name="allowDeleteChannels"
                          />
                        }
                        label="allowDeleteChannels"
                      />
                      <FormControlLabel
                        control={
                          <Switch
                            checked={channelSettings.allowAddRemoveApps}
                            onChange={handleChannelSettingChange}
                            name="allowAddRemoveApps"
                          />
                        }
                        label="allowAddRemoveApps"
                      />
                      <FormControlLabel
                        control={
                          <Switch
                            checked={
                              channelSettings.allowCreateUpdateRemoveTabs
                            }
                            onChange={handleChannelSettingChange}
                            name="allowCreateUpdateRemoveTabs"
                          />
                        }
                        label="allowCreateUpdateRemoveTabs"
                      />
                      <FormControlLabel
                        control={
                          <Switch
                            checked={
                              channelSettings.allowCreateUpdateRemoveConnectors
                            }
                            onChange={handleChannelSettingChange}
                            name="allowCreateUpdateRemoveConnectors"
                          />
                        }
                        label="allowCreateUpdateRemoveConnectors"
                      />
                    </Box>
                  </Box>

                  <Box className='col-xl-4 col-md-4 col-sm-6 d-flex'>
                    <Box className='advance-setting-box'>
                      <h6>Guest Setting </h6>
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Switch
                              checked={
                                channelSettings.allowCreateUpdateChannelsGuest
                              }
                              onChange={handleChannelSettingChange}
                              name="allowCreateUpdateChannelsGuest"
                            />
                          }
                          label="allowCreateUpdateChannels"
                        />
                        <FormControlLabel
                          control={
                            <Switch
                              checked={
                                channelSettings.allowDeleteChannelsGuest
                              }
                              onChange={handleChannelSettingChange}
                              name="allowDeleteChannelsGuest"
                            />
                          }
                          label="allowDeleteChannels"
                        />
                      </FormGroup>
                    </Box>
                  </Box>

                  <Box className='col-xl-4 col-md-4 col-sm-6 d-flex'>
                    <Box className='advance-setting-box'>
                      <FormGroup>
                        <h6>Fun Setting</h6>

                        <Box className="clearfix">
                          <FormControlLabel
                            control={<Switch />}
                            label="allowGiphy"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={channelSettings.allowDeleteChannelsFun}
                                onChange={handleChannelSettingChange}
                                name="allowDeleteChannelsFun"
                              />
                            }
                            label="giphyContentRating"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowStickersAndMemesFun
                                }
                                onChange={handleChannelSettingChange}
                                name="allowStickersAndMemesFun"
                              />
                            }
                            label="allowStickersAndMemes"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={channelSettings.allowCustomMemesFun}
                                onChange={handleChannelSettingChange}
                                name="allowCustomMemesFun"
                              />
                            }
                            label="allowCustomMemes"
                          />
                        </Box>
                      </FormGroup>
                    </Box>
                  </Box>

                  <Box className='col-xl-4 col-md-4 col-sm-6 d-flex'>
                    <Box className="advance-setting-box">
                      <h6>Message Setting</h6>
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Switch
                              checked={channelSettings.allowUserEditMessages}
                              onChange={handleChannelSettingChange}
                              name="allowUserEditMessages"
                            />
                          }
                          label="allowUserEditMessages"
                        />
                        <FormControlLabel
                          control={
                            <Switch
                              checked={
                                channelSettings.allowUserDeleteMessages
                              }
                              onChange={handleChannelSettingChange}
                              name="allowUserDeleteMessages"
                            />
                          }
                          label="allowUserDeleteMessages"
                        />
                        <FormControlLabel
                          control={
                            <Switch
                              checked={
                                channelSettings.allowOwnerDeleteMessages
                              }
                              onChange={handleChannelSettingChange}
                              name="allowOwnerDeleteMessages"
                            />
                          }
                          label="allowOwnerDeleteMessages"
                        />
                        <FormControlLabel
                          control={
                            <Switch
                              checked={channelSettings.allowTeamMentions}
                              onChange={handleChannelSettingChange}
                              name="allowTeamMentions"
                            />
                          }
                          label="allowTeamMentions"
                        />
                        <FormControlLabel
                          control={
                            <Switch
                              checked={channelSettings.allowChannelMentions}
                              onChange={handleChannelSettingChange}
                              name="allowChannelMentions"
                            />
                          }
                          label="allowChannelMentions"
                        />
                      </FormGroup>

                    </Box>
                  </Box>

                  <Box className='col-xl-4 col-md-4 col-sm-6 d-flex'>
                    <Box className="advance-setting-box">
                      <h6>Discovery Setting</h6>
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Switch
                              checked={
                                channelSettings.showInTeamsSearchAndSuggestions
                              }
                              onChange={handleChannelSettingChange}
                              name="showInTeamsSearchAndSuggestions"
                            />
                          }
                          label="showInTeamsSearchAndSuggestions"
                        />
                      </FormGroup>
                    </Box>
                  </Box>
                </Box>
              </Box>
            )}
          </div>
          {/* {setting start data end here } */}
        </Box >
    },
  ]

  return (
    <Box>
      <Row>
        <Col>

          {/* stepper start */}
          <Box >
            <Stepper activeStep={activeStep} orientation="vertical">
              {steps.map((step, index) => (
                <Step key={step.label}>
                  <StepLabel
                    optional={
                      index === 2 ? (
                        <Typography variant="caption" className="d-none">Last step</Typography>
                      ) : null
                    }
                  >
                    {step.label}
                  </StepLabel>
                  <StepContent>
                    {/* <Typography>{step.description}</Typography> */}
                    <Box>
                      {step.description}
                    </Box>
                    <Box sx={{ mb: 2, mt: 2 }}>
                      <div>
                        <Button
                          variant="contained"
                          onClick={handleNext}
                          sx={{ mt: 1, mr: 1 }}
                          className="btn-blue"
                        >
                          {index === steps.length - 1 ? 'Add Client' : 'Continue'}
                        </Button>
                        <Button
                          disabled={index === 0}
                          onClick={handleBack}
                          sx={{ mt: 1, mr: 1 }}
                        >
                          Back
                        </Button>
                      </div>
                    </Box>
                  </StepContent>
                </Step>
              ))}
            </Stepper>
            {activeStep === steps.length && (
              <Paper square elevation={0} sx={{ p: 3 }}>
                <Typography>All steps completed - you&apos;re finished</Typography>
                <Button onClick={handleReset} sx={{ mt: 1, mr: 1 }}>
                  Reset
                </Button>
              </Paper>
            )}
          </Box>
          {/* stepper end */}

          <Box>
            <Button
              style={{ marginTop: "5px" }}
              variant="contained"
              disabled={!clientData || !folderData}
              onClick={handleSubmit}
              className="btn-blue"
            >
              Add Client
            </Button>{" "}
            {/* <Button style={{ marginTop: "5px" }}  variant="contained" onClick={handleSubmit}>
        Add Client
      </Button>{" "} */}
          </Box>
        </Col>
      </Row>
    </Box>
  );
}
interface FilmOptionType {
  Name: string;
  Status: string;
  TemplateId: number;
}
interface FolderList {
  Folder: string;
  FolderID: number;
}
interface BussinessList {
  Client: string;
  ClientID: number;
}

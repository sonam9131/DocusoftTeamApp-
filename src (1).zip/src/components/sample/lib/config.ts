const config = {
  initiateLoginEndpoint: "https://practicetest.docusoftweb.com/Office365Teams/build/auth-start.html",//process.env.REACT_APP_START_LOGIN_PAGE_URL,
  clientId: "99472e5a-9bcc-4e86-9bf4-7e7ce715522f",//process.env.REACT_APP_CLIENT_ID,
  apiEndpoint: process.env.REACT_APP_FUNC_ENDPOINT,//process.env.REACT_APP_FUNC_ENDPOINT,
  apiName: 'getUserProfile',//process.env.REACT_APP_FUNC_NAME,
};

export default config;

import { ExpandMore } from "@mui/icons-material";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Autocomplete,
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  Stack,
  Switch,
  TextField,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  SelectTabData,
  SelectTabEvent,
  Tab,
  TabList,
  TabValue,
} from "@fluentui/react-components";
import React, { useEffect, useState } from "react";
import CallApi, { CallApiphp } from "./sample/Services/Apicall";
import Templatelist from "./Templatelist";
import MergeComponent from "./Merge";
let agrno: any = localStorage.getItem("agrno");
let email: any = localStorage.getItem("email");
let password: any = localStorage.getItem("pass");
export default function Admin() {
  const [showAdditionalFields, setShowAdditionalFields] = useState(false);
  const [additionalFieldsCount, setAdditionalFieldsCount] = useState(0);
  const [age, setAge] = useState("");
  const [groupname, setGroupname] = useState<any>("");
  const [description, setDescription] = useState<any>("");
  const [channelname, setChannelname] = useState<any>("");
  const [channeldes, setChanneldes] = useState<any>("");
  const [checkboxfeb, setCheckboxfeb] = useState<any>("");
  const [channels, setChannels] = useState([]);
  const [tabs, setTabs] = useState<any>([]);
  const [tabsapidata, setTabsapidata] = useState<any>([]);
  const [advancedSettingChecked, setAdvancedSettingChecked] = useState(true);
  const [isviblebutton, setIsviblebutton] = useState<any>(true);
  const [channels1true, setChannels1true] = useState<any>(false);
  const [isCreateButton, setIsCreateButton] = useState<any>(false);
  const [channels1, setChannels1] = useState<any>([
    {
      channelname: "",
      checkboxfeb: "",
      channeldes: "",
      gilad: false,
      jason: false,
      antoine: false,
    },
  ]);

  const [state, setState] = useState<any>({
    gilad: false,
    jason: false,
    antoine: false,
  });

  const [newChannels, setNewChannels] = useState<any>([]);
  const [channelSettings, setChannelSettings] = useState({
    allowCreateUpdateChannels: false,
    allowDeleteChannels: false,
    allowAddRemoveApps: false,
    allowCreateUpdateRemoveTabs: false,
    allowCreateUpdateRemoveConnectors: false,
    allowCreateUpdateChannelsGuest: false,
    allowDeleteChannelsGuest: false,
    allowDeleteChannelsFun: false,
    allowStickersAndMemesFun: false,
    allowCustomMemesFun: false,
    allowUserEditMessages: false,
    allowUserDeleteMessages: false,
    allowOwnerDeleteMessages: false,
    allowTeamMentions: false,
    allowChannelMentions: false,
    showInTeamsSearchAndSuggestions: false,
  });
  const handleChannelSettingChange = (event: any) => {
    const { name, checked } = event.target;
    setChannelSettings((prevSettings) => ({
      ...prevSettings,
      [name]: checked,
    }));
  };
  const handleAdvancedSettingChange = (event: any) => {
    setAdvancedSettingChecked(event.target.checked);
  };
  const toggleAdditionalFields = () => {
    setChannelname(null);
    setCheckboxfeb(false);
    setState(false);
    setChanneldes(null);
    setTabs([]);
    setShowAdditionalFields(true);
    // setShowAdditionalFields(!showAdditionalFields);
    setAdditionalFieldsCount((prevCount) => prevCount + 1);
    let createChannalData = {
      "template@odata.bind":
        "https://graph.microsoft.com/v1.0/teamsTemplates('standard')",
      visibility: age ? age : "",
      displayName: groupname ? groupname : "",
      description: description ? description : "",
      //   "members":[
      //     {
      //        "@odata.type":"#microsoft.graph.aadUserConversationMember",
      //        "roles":[
      //           "owner"
      //        ],
      //        "user@odata.bind":"https://graph.microsoft.com/v1.0/users('0040b377-61d8-43db-94f5-81374122dc7e')"
      //     },
      //     {
      //        "@odata.type":"#microsoft.graph.aadUserConversationMember",
      //        "roles":[
      //           "guest"
      //        ],
      //        "user@odata.bind":"https://graph.microsoft.com/v1.0/users('0040b377-61d8-43db-94f5-81374122dc7e')"
      //     }
      //  ],
      channels: channels,
      memberSettings: {
        allowCreateUpdateChannels: channelSettings.allowCreateUpdateChannels,
        allowDeleteChannels: channelSettings.allowDeleteChannels,
        allowAddRemoveApps: channelSettings.allowAddRemoveApps,
        allowCreateUpdateRemoveTabs:
          channelSettings.allowCreateUpdateRemoveTabs,
        allowCreateUpdateRemoveConnectors:
          channelSettings.allowCreateUpdateRemoveConnectors,
      },
      guestSettings: {
        allowCreateUpdateChannels:
          channelSettings.allowCreateUpdateChannelsGuest,
        allowDeleteChannels: channelSettings.allowDeleteChannelsGuest,
      },
      funSettings: {
        allowGiphy: channelSettings.allowDeleteChannelsFun,
        giphyContentRating: "Moderate"
          ? "Moderate"
          : channelSettings.allowDeleteChannelsFun,
        allowStickersAndMemes: channelSettings.allowStickersAndMemesFun,
        allowCustomMemes: channelSettings.allowCustomMemesFun,
      },
      messagingSettings: {
        allowUserEditMessages: channelSettings.allowUserEditMessages,
        allowUserDeleteMessages: channelSettings.allowUserDeleteMessages,
        allowOwnerDeleteMessages: channelSettings.allowOwnerDeleteMessages,
        allowTeamMentions: channelSettings.allowTeamMentions,
        allowChannelMentions: channelSettings.allowChannelMentions,
      },
      discoverySettings: {
        showInTeamsSearchAndSuggestions:
          channelSettings.showInTeamsSearchAndSuggestions,
      },
      installedApps: [
        {
          "teamsApp@odata.bind":
            "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps('com.microsoft.teamspace.tab.vsts')",
        },
        {
          "teamsApp@odata.bind":
            "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps('1542629c-01b3-4a6d-8f76-1938b779e48d')",
        },
      ],
    };
    
    const createMSTeamsTemplatesWithChannelsTabs = () => {
      let passdata: any = localStorage.getItem("pass");
      let requestBody = {
        agrno: agrno,
        strEmail: email,
        password: password,
        Name: groupname ? groupname : "",
        TemplateData: channels,
        TabseCheck: channels1true,
        TemplateSettings: {
          memberSettings: {
            allowCreateUpdateChannels:
              channelSettings.allowCreateUpdateChannels,
            allowDeleteChannels: channelSettings.allowDeleteChannels,
            allowAddRemoveApps: channelSettings.allowAddRemoveApps,
            allowCreateUpdateRemoveTabs:
              channelSettings.allowCreateUpdateRemoveTabs,
            allowCreateUpdateRemoveConnectors:
              channelSettings.allowCreateUpdateRemoveConnectors,
          },
          guestSettings: {
            allowCreateUpdateChannels:
              channelSettings.allowCreateUpdateChannelsGuest,
            allowDeleteChannels: channelSettings.allowDeleteChannelsGuest,
          },
          funSettings: {
            allowGiphy: channelSettings.allowDeleteChannelsFun,
            giphyContentRating: "Moderate"
              ? "Moderate"
              : channelSettings.allowDeleteChannelsFun,
            allowStickersAndMemes: channelSettings.allowStickersAndMemesFun,
            allowCustomMemes: channelSettings.allowCustomMemesFun,
          },
          messagingSettings: {
            allowUserEditMessages: channelSettings.allowUserEditMessages,
            allowUserDeleteMessages: channelSettings.allowUserDeleteMessages,
            allowOwnerDeleteMessages: channelSettings.allowOwnerDeleteMessages,
            allowTeamMentions: channelSettings.allowTeamMentions,
            allowChannelMentions: channelSettings.allowChannelMentions,
          },
          discoverySettings: {
            showInTeamsSearchAndSuggestions:
              channelSettings.showInTeamsSearchAndSuggestions,
          },
        },
      };
      console.log("getDomian", requestBody);
      CallApiphp(
        requestBody,
        "createMSTeamsTemplatesWithChannelsTabs",
        function (res: any) {
          if (res) {
            console.log(res, "response11");
          } else {
          }
        }
      );
    };
    // createMSTeamsTemplatesWithChannelsTabs();
    console.log(
      tabs,
      "createChannalData",
      createChannalData,
      "ddfgfdgdfgfdgdfg",
      channels
    );
    // console.log(newChannels,"newchanneldata",newTab);
  };
  const Json_getMSTeamsTabList = () => {
    let requestBody = {
      agrno: agrno,
      Email: email,
      password: password,
    };
    CallApi(requestBody, "Json_getMSTeamsTabList", function (res: any) {
      if (res) {
        console.log(res, "Json_getMSTeamsTabList");
        let str = JSON.parse(JSON.stringify(res));
        let json = JSON.parse(str.d);
        console.log(json, "Json_getMSTeamsTabList");
        console.log(json.Table, "table1111111");
        setTabsapidata(json.Table);
      } else {
      }
    });
  };
  useEffect(() => {
    Json_getMSTeamsTabList();
  }, []);
  const handleChangeTabs = (
    event: React.ChangeEvent<HTMLInputElement>,
    index: any
  ) => {
    const isChecked = event.target.checked;
    console.log(isChecked, "isChecked", tabsapidata);
    setChannels1true(event.target.checked);
    const newChannels: any = [...channels];
    let newTabs: any = [...tabs];

    // Create a new tab object structure
    const newTab = {
      teamsApp: {
        "@odata.bind":
          "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps('com.microsoft.teamspace.tab.web')",
      },
      displayName: event.target.name,
      configuration: {
        contentUrl: tabsapidata[0].BaseUrl,
      },
    };

    if (isChecked) {
      // Add the new tab object to the tabs array
      newTabs.push(newTab);
    } else {
      // Remove the tab object from the tabs array if the checkbox is unchecked
      const tabIndex = newTabs.findIndex(
        (tab: any) => tab.displayName === event.target.name
      );
      if (tabIndex !== -1) {
        newTabs.splice(tabIndex, 1);
      }
    }

    // Update the channels array with tabs information
    newChannels[index] = {
      ...newChannels[index],
      tabs: newTabs, // Set tabs to newTabs array
    };

    // Update state
    setTabs(newTabs);
    setChannels(newChannels);
    console.log(newChannels, "newChannelsAdmin");
  };

  //   const handleChangeTabs = (
  //     event: React.ChangeEvent<HTMLInputElement>,
  //     index: any
  //   ) => {
  //     const isChecked = event.target.checked;
  //     const newChannels: any = [...channels];
  //     const newTabs: any = [...tabs];
  //     console.log(newTabs,"newTabsnewTabsnewTabs");
  //     // Create a new tab object structure
  //     const newTab = {
  //       teamsApp: {
  //         '@odata.bind': "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps('com.microsoft.teamspace.tab.web')",
  //       },
  //       displayName: event.target.name,
  //       configuration: {
  //         contentUrl: "https://learn.microsoft.com/microsoftteams/microsoft-teams"
  //       }
  //     };

  //     if (isChecked) {
  //       // Add the new tab object to the tabs array

  //       newTabs.push(newTab);
  //     } else {
  //       // Remove the tab object from the tabs array if the checkbox is unchecked
  //       const tabIndex = newTabs.findIndex((tab:any) => tab.displayName === event.target.name);
  //       if (tabIndex !== -1) {
  //         newTabs.splice(tabIndex, 1);
  //       }
  //     }

  //     // Update the channels array with tabs information
  //     newChannels[index] = {
  //       ...newChannels[index],
  //       tabs: isChecked ? newTabs : [] // Set tabs to newTabs if isChecked is true, otherwise set to an empty array
  //     };

  //     // Update state
  //     setTabs(newTabs);
  //     setChannels(newChannels);
  // };

  const handleChangeTabs44 = (
    event: React.ChangeEvent<HTMLInputElement>,
    index: any
  ) => {
    // const isChecked = event.target.checked;
    // const updatedChannels:any = [...channels];
    // //  setState({
    // //   ...state,
    // //   tabs: event.target.checked,
    // // });
    // if (isChecked) {
    //   // Create a new tab object structure
    //   const newTab = {
    //     teamsApp: {
    //       '@odata.bind': "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps('com.microsoft.teamspace.tab.web')",
    //     },
    //     displayName: event.target.name,
    //     configuration: {
    //       contentUrl: "https://learn.microsoft.com/microsoftteams/microsoft-teams"
    //     }
    //   };

    //   // Add the new tab object to the channels array at the specified index
    //   updatedChannels[index] = {
    //     ...updatedChannels[index],
    //     tabs: [newTab]  // Add tabs property with value true
    //   };

    //   // Add the new tab object to the tabs array
    //   setTabs((prevTabs:any) => [...prevTabs, newTab]);
    // }

    // setChannels(channels);

    const newChannels: any = [...channels];
    const newChannels1: any = [...channels];

    // const newChannels: any = [...channels];
    setState({
      ...state,
      tabs: tabs,
    });

    const isChecked = event.target.checked;
    // const newChannels = [...channels];
    newChannels[index] = {
      ...newChannels[index],
      tabs: tabs,
    };
    if (isChecked) {
      // Create a new tab object structure
      const newTab = {
        teamsApp: {
          "@odata.bind":
            "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps('com.microsoft.teamspace.tab.web')",
        },
        displayName: event.target.name,
        configuration: {
          contentUrl:
            "https://learn.microsoft.com/microsoftteams/microsoft-teams",
        },
      };

      // Add the new tab object to the channels array at the specified index
      newChannels1[index] = newTab;
      setTabs((prevTabs: any) => [...prevTabs, newTab]);

      console.log(tabs, "tabstabstabs");
    }

    setChannels(newChannels);
  };
  const handleChange = (event: SelectChangeEvent) => {
    setAge(event.target.value as string);
  };
  const handleChangeName = (event: any) => {
    setGroupname(event.target.value);
  };
  const handleChangeDescrition = (event: any) => {
    setDescription(event.target.value);
  };
  const handleChannelName = (event: any, index: any) => {
    setChannelname(event.target.value);
    const newChannels: any = [...channels];
    newChannels[index] = {
      ...newChannels[index],
      displayName: event.target.value,
    };
    setChannels(newChannels);
  };
  const handleChannelDes = (event: any, index: any) => {
    setChanneldes(event.target.value);
    const newChannels: any = [...channels];
    newChannels[index] = {
      ...newChannels[index],
      description: event.target.value,
    };
    setChannels(newChannels);
  };
  const handleChannecheck = (event: any, index: any) => {
    const newChannels1: any = [...channels];
    newChannels1[index] = {
      ...newChannels1[index],
      checkboxfeb: event.target.checked,
    };
    setChannels(newChannels1);

    setCheckboxfeb(index);

    const newChannels: any = [...channels];
    newChannels[index] = {
      ...newChannels[index],
      isFavoriteByDefault: event.target.checked,
    };
    setChannels(newChannels);
  };
  const deleteChannel = (index: any) => {
    const newChannels = [...channels];
    newChannels.splice(index, 1);
    setChannels(newChannels);
  };
  const additionalFields: any = [];
  const { gilad, jason, antoine } = state;
  const [expanded, setExpanded] = useState<string | false>(false);

  const handleChangeaccord =
    (panel: string) => (_event: React.ChangeEvent<{}>, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

  for (let i = 0; i < additionalFieldsCount; i++) {
    additionalFields.push(
      <div key={i}>
        <h5>Channel-{i + 1}</h5>
        <div style={{ marginBottom: "20px" }}>
          <TextField
            fullWidth
            id={`standard-basic-client-${i}`}
            label="Channel Name"
            variant="standard"
            value={channels1.channelname}
            onChange={(e) => handleChannelName(e, i)}
            name={`Clientname-${i}`}
          />
        </div>
        <div style={{ marginBottom: "20px" }}>
          {/* <FormLabel component="legend">Favorite Channel</FormLabel>
          <Checkbox
            name={`jason-${i}`}
            checked={channels1.checkboxfeb}
            onChange={(e) => handleChannecheck(e, i)}
          /> */}
          <FormGroup>
            <FormControlLabel
              control={
                <Switch
                  name={`jason-${i}`}
                  checked={checkboxfeb === i}
                  onChange={(e) => handleChannecheck(e, i)}
                />
              }
              label="Favorite Channel"
            />
          </FormGroup>
        </div>
        <div style={{ marginBottom: "20px" }}>
          <FormControl fullWidth variant="standard">
            <TextField
              aria-label="minimum height"
              minRows={3}
              name={`fullAddress-${i}`}
              value={channels1.channeldes}
              onChange={(e) => handleChannelDes(e, i)}
              variant="standard"
              label="Channel Description"
            />
          </FormControl>
        </div>
        <div style={{ marginBottom: "20px" }}>
          {/* <Box sx={{ display: "flex" }}>
            <FormControl sx={{ m: 3 }} component="fieldset" variant="standard">
              <FormLabel component="legend">Channel Tab</FormLabel>
              <FormGroup>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={channels1.gilad}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="gilad"
                    />
                  }
                  label="Client"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={channels1.jason}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="jason"
                    />
                  }
                  label="Task"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={channels1.antoine}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="antoine"
                    />
                  }
                  label="DMS"
                />
              </FormGroup>
            </FormControl>
            <FormControl
              required
              sx={{ m: 3 }}
              variant="standard"
            ></FormControl>
             
          </Box> */}
          <FormLabel component="legend">Channel Tab  </FormLabel>
          <FormGroup>
            {tabsapidata &&
              tabsapidata.map((item: any, i: any) => (
                <FormControlLabel
                  control={
                    <Switch
                      checked={channels1true}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name={item.TabName}
                    />
                  }
                  label={item.TabName}
                />
              ))}

            {/* <FormControlLabel
                      control={<Switch   checked={channels1.jason}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="Task"/>}
                      label="Task"
                    />

<FormControlLabel
                      control={<Switch   checked={channels1.antoine}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="DMS"/>}
                      label="DMS"
                    />
                    
                   */}
          </FormGroup>
        </div>
      </div>
    );
  }
  const [selectedValue, setSelectedValue] = useState<TabValue>("local");
  const onTabSelect = (event: SelectTabEvent, data: SelectTabData) => {
    setSelectedValue(data.value);
  };
  console.log(channels, "channelschannels", channelSettings);
  const [showCreateTemplate, setShowCreateTemplate] = useState(false);

  const CreateTemplate =() => {
    setShowCreateTemplate(!showCreateTemplate);
  }
  return (
    <div className="tabList container">
      <TabList selectedValue={selectedValue} onTabSelect={onTabSelect} className='custom-tabs'>
        <Tab className="btn-tabs" id="Local" value="local">
          1. TEMPLATE SETTING  ADG
        </Tab>
        <Tab className="btn-tabs" id="Azure" value="azure">
          2. MY CLIENT
        </Tab>
        <Tab className="btn-tabs" id="Publish" value="publish">
          3. All CLIENTS
        </Tab>
      </TabList>
      <div>
        {selectedValue === "local" && (
          <MergeComponent />

          // <div>
           
          //   <div
          //     className="clearfix"
          //     style={{ marginTop: "20px", maxWidth: "800px", margin: "0 auto" }}
          //   >
              
          //      {/* <Templatelist /> */}
          //      {showCreateTemplate ? (
          //     <div className="row">
          //       <div className="col">
          //         {/* <h6>Group</h6> */}
          //         <div style={{ marginBottom: "20px" }}>
          //           <TextField
          //             fullWidth
          //             id="standard-basic-client"
          //             label="Template Name"
          //             variant="standard"
          //             name="Clientname"
          //             value={groupname}
          //             onChange={handleChangeName}
          //           />
          //         </div>
                
          //         <div style={{ marginBottom: "20px" }}>
          //           <Accordion
          //             expanded={expanded === "panel1"}
          //             onChange={handleChangeaccord("panel1")}
          //           >
          //             {/* <Accordion expanded={true} onChange={handleChange('panel1')}> */}

          //             <AccordionSummary
          //               expandIcon={<ExpandMore />}
          //               aria-controls="panel1-content"
          //               id="panel1-header"
          //             >
          //               <h6>Advanced Setting</h6>
          //             </AccordionSummary>
          //             <AccordionDetails>
          //               <FormGroup>
          //                 <FormControlLabel
          //                   control={
          //                     <Switch
          //                       checked={advancedSettingChecked}
          //                       onChange={handleAdvancedSettingChange}
          //                     />
          //                   }
          //                   label="Use Default"
          //                 />
          //                 {/* <FormControlLabel
          //             control={<Switch defaultChecked />}
          //             label="Use Default"
          //           /> */}
          //               </FormGroup>
          //             </AccordionDetails>
          //           </Accordion>
          //           {!advancedSettingChecked && (
          //             <div>
          //               <Accordion
          //                 expanded={expanded === "panel2"}
          //                 onChange={handleChangeaccord("panel2")}
          //               >
          //                 <AccordionSummary
          //                   expandIcon={<ExpandMore />}
          //                   aria-controls="panel2-content"
          //                   id="panel2-header"
          //                 >
          //                   <h6>Member Setting </h6>
          //                 </AccordionSummary>
          //                 <AccordionDetails>
          //                   <FormGroup>
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowCreateUpdateChannels
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowCreateUpdateChannels"
          //                         />
          //                       }
          //                       label="allowCreateUpdateChannels"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowDeleteChannels
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowDeleteChannels"
          //                         />
          //                       }
          //                       label="allowDeleteChannels"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={channelSettings.allowAddRemoveApps}
          //                           onChange={handleChannelSettingChange}
          //                           name="allowAddRemoveApps"
          //                         />
          //                       }
          //                       label="allowAddRemoveApps"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowCreateUpdateRemoveTabs
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowCreateUpdateRemoveTabs"
          //                         />
          //                       }
          //                       label="allowCreateUpdateRemoveTabs"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowCreateUpdateRemoveConnectors
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowCreateUpdateRemoveConnectors"
          //                         />
          //                       }
          //                       label="allowCreateUpdateRemoveConnectors"
          //                     />
          //                   </FormGroup>
          //                 </AccordionDetails>
          //               </Accordion>
          //               <Accordion
          //                 expanded={expanded === "panel3"}
          //                 onChange={handleChangeaccord("panel3")}
          //               >
          //                 <AccordionSummary
          //                   expandIcon={<ExpandMore />}
          //                   aria-controls="panel3-content"
          //                   id="panel3-header"
          //                 >
          //                   <h6>Guest Setting </h6>
          //                 </AccordionSummary>
          //                 <AccordionDetails>
          //                   <FormGroup>
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowCreateUpdateChannelsGuest
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowCreateUpdateChannelsGuest"
          //                         />
          //                       }
          //                       label="allowCreateUpdateChannels"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowDeleteChannelsGuest
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowDeleteChannelsGuest"
          //                         />
          //                       }
          //                       label="allowDeleteChannels"
          //                     />
          //                   </FormGroup>
          //                 </AccordionDetails>
          //               </Accordion>
          //               <Accordion
          //                 expanded={expanded === "panel4"}
          //                 onChange={handleChangeaccord("panel4")}
          //               >
          //                 <AccordionSummary
          //                   expandIcon={<ExpandMore />}
          //                   aria-controls="panel4-content"
          //                   id="panel4-header"
          //                 >
          //                   <h6>Fun Setting</h6>
          //                 </AccordionSummary>
          //                 <AccordionDetails>
          //                   <FormGroup>
          //                     <FormControlLabel
          //                       control={<Switch />}
          //                       label="allowGiphy"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowDeleteChannelsFun
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowDeleteChannelsFun"
          //                         />
          //                       }
          //                       label="giphyContentRating"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowStickersAndMemesFun
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowStickersAndMemesFun"
          //                         />
          //                       }
          //                       label="allowStickersAndMemes"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowCustomMemesFun
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowCustomMemesFun"
          //                         />
          //                       }
          //                       label="allowCustomMemes"
          //                     />
          //                   </FormGroup>
          //                 </AccordionDetails>
          //               </Accordion>
          //               <Accordion
          //                 expanded={expanded === "panel5"}
          //                 onChange={handleChangeaccord("panel5")}
          //               >
          //                 <AccordionSummary
          //                   expandIcon={<ExpandMore />}
          //                   aria-controls="panel5-content"
          //                   id="panel5-header"
          //                 >
          //                   <h6>Message Setting</h6>
          //                 </AccordionSummary>
          //                 <AccordionDetails>
          //                   <FormGroup>
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowUserEditMessages
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowUserEditMessages"
          //                         />
          //                       }
          //                       label="allowUserEditMessages"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowUserDeleteMessages
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowUserDeleteMessages"
          //                         />
          //                       }
          //                       label="allowUserDeleteMessages"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowOwnerDeleteMessages
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowOwnerDeleteMessages"
          //                         />
          //                       }
          //                       label="allowOwnerDeleteMessages"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={channelSettings.allowTeamMentions}
          //                           onChange={handleChannelSettingChange}
          //                           name="allowTeamMentions"
          //                         />
          //                       }
          //                       label="allowTeamMentions"
          //                     />
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.allowChannelMentions
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="allowChannelMentions"
          //                         />
          //                       }
          //                       label="allowChannelMentions"
          //                     />
          //                   </FormGroup>
          //                 </AccordionDetails>
          //               </Accordion>
          //               <Accordion
          //                 expanded={expanded === "panel6"}
          //                 onChange={handleChangeaccord("panel6")}
          //               >
          //                 <AccordionSummary
          //                   expandIcon={<ExpandMore />}
          //                   aria-controls="panel6-content"
          //                   id="panel6-header"
          //                 >
          //                   <h6>Discovery Setting</h6>
          //                 </AccordionSummary>
          //                 <AccordionDetails>
          //                   <FormGroup>
          //                     <FormControlLabel
          //                       control={
          //                         <Switch
          //                           checked={
          //                             channelSettings.showInTeamsSearchAndSuggestions
          //                           }
          //                           onChange={handleChannelSettingChange}
          //                           name="showInTeamsSearchAndSuggestions"
          //                         />
          //                       }
          //                       label="showInTeamsSearchAndSuggestions"
          //                     />
          //                   </FormGroup>
          //                 </AccordionDetails>
          //               </Accordion>
          //             </div>
          //           )}
          //         </div>
          //         {showAdditionalFields && additionalFields}
          //         <div style={{ marginBottom: "20px" }}>
          //           <Stack spacing={2} direction="row">
          //             <Button
          //               variant="contained"
          //               onClick={toggleAdditionalFields}
          //               disabled={!groupname}
          //             >
          //               Add Channel
          //             </Button>
          //             <Button variant="contained" 
          //              onClick={CreateTemplate}
          //     // onClick={toggleAdditionalFields}
          //     // disabled={
          //     //   !groupname
          //     // }
          //     >
          //         Cancel
          //       </Button>
          //             {/* <Button variant="outlined" startIcon={<DeleteIcon />}
          //       //  onClick={(e) => deleteChannel(e, i)}
          //       onClick={(e) => deleteChannel(e, i)}
          //       >
          //       Delete Channel
          //       </Button> */}

          //             {/* <AddIcon /> */}
          //           </Stack>
          //         </div>
          //       </div>
          //     </div>
          //      ) : (
          //       <>
          //       {isviblebutton && (<Button
          //               variant="contained"
          //               onClick={CreateTemplate}
          //               // disabled={!groupname}
          //             >
          //               Create Template
          //             </Button>)}
              
          //             <Templatelist setIsviblebutton ={setIsviblebutton} />
          //       </>
            
          //     )}
          //   </div>
          // </div>
        )}
      </div>
    </div>
  );
}

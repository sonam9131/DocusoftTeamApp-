import { ExpandMore } from "@mui/icons-material";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  Stack,
  Switch,
  Box,
  Grid,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import CallApi, { CallApiphp } from "./sample/Services/Apicall";
import Templatelist from "./Templatelist";
import Admin from "./Admin";
import Merge from "./Merge";
let agrno: any = localStorage.getItem("agrno");
let email: any = localStorage.getItem("email");
let password: any = localStorage.getItem("pass");
export default function EditAdmin({ showInput, templatesettings, templatedata, templateID }: any) {
  console.log(templatedata, "Edit-Admin", templatesettings);
  const [additionalFieldsCount, setAdditionalFieldsCount] = useState(0);
  const [isviblebutton, setIsviblebutton] = useState<any>(true);
  const [groupname, setGroupname] = useState<any>("");
  const [description, setDescription] = useState<any>("");
  const [channelname, setChannelname] = useState<any>("");
  const [channeldes, setChanneldes] = useState<any>("");
  const [checkboxfeb, setCheckboxfeb] = useState(false);
  const [channels, setChannels] = useState<any>([]);
  const [tabs, setTabs] = useState<any>([]);
  const [tabsapidata, setTabsapidata] = useState<any>([]);
  const [advancedSettingChecked, setAdvancedSettingChecked] = useState(true);
  const [channels1true, setChannels1true] = useState<any>(false);
  const [template, setTemplate] = useState<any>(null);
  const [templatesettings1, setTemplatesettings1] = useState<any>(null);
  const [channelSettings, setChannelSettings] = useState({
    allowCreateUpdateChannels: false,
    allowDeleteChannels: false,
    allowAddRemoveApps: false,
    allowCreateUpdateRemoveTabs: false,
    allowCreateUpdateRemoveConnectors: false,
    allowCreateUpdateChannelsGuest: false,
    allowDeleteChannelsGuest: false,
    allowDeleteChannelsFun: false,
    allowStickersAndMemesFun: false,
    allowCustomMemesFun: false,
    allowUserEditMessages: false,
    allowUserDeleteMessages: false,
    allowOwnerDeleteMessages: false,
    allowTeamMentions: false,
    allowChannelMentions: false,
    showInTeamsSearchAndSuggestions: false,
  });
  const handleChannelSettingChange = (event: any) => {
    const { name, checked } = event.target;
    setChannelSettings((prevSettings) => ({
      ...prevSettings,
      [name]: checked,
    }));
  };
  const handleAdvancedSettingChange = (event: any) => {
    setAdvancedSettingChecked(event.target.checked);
  };
  const toggleAdditionalFields = () => {
    // setChannelname(null);
    // setCheckboxfeb(false);
    // setState(false);
    // setChanneldes(null);
    // setTabs([]);
    // setShowAdditionalFields(true);
    // setShowAdditionalFields(!showAdditionalFields);
    setAdditionalFieldsCount((prevCount) => prevCount + 1);

    const createMSTeamsTemplatesWithChannelsTabs = () => {
      let passdata: any = localStorage.getItem("pass");
      let requestBody = {
        agrno: agrno,
        strEmail: email,
        password: password,
        Name: groupname ? groupname : "",
        TemplateData: channels && channels.length > 0 ? channels : templatedata,
        TemplateSettings: {
          memberSettings: {
            allowCreateUpdateChannels:
              channelSettings.allowCreateUpdateChannels,
            allowDeleteChannels: channelSettings.allowDeleteChannels,
            allowAddRemoveApps: channelSettings.allowAddRemoveApps,
            allowCreateUpdateRemoveTabs:
              channelSettings.allowCreateUpdateRemoveTabs,
            allowCreateUpdateRemoveConnectors:
              channelSettings.allowCreateUpdateRemoveConnectors,
          },
          guestSettings: {
            allowCreateUpdateChannels:
              channelSettings.allowCreateUpdateChannelsGuest,
            allowDeleteChannels: channelSettings.allowDeleteChannelsGuest,
          },
          funSettings: {
            allowGiphy: channelSettings.allowDeleteChannelsFun,
            giphyContentRating: "Moderate"
              ? "Moderate"
              : channelSettings.allowDeleteChannelsFun,
            allowStickersAndMemes: channelSettings.allowStickersAndMemesFun,
            allowCustomMemes: channelSettings.allowCustomMemesFun,
          },
          messagingSettings: {
            allowUserEditMessages: channelSettings.allowUserEditMessages,
            allowUserDeleteMessages: channelSettings.allowUserDeleteMessages,
            allowOwnerDeleteMessages: channelSettings.allowOwnerDeleteMessages,
            allowTeamMentions: channelSettings.allowTeamMentions,
            allowChannelMentions: channelSettings.allowChannelMentions,
          },
          discoverySettings: {
            showInTeamsSearchAndSuggestions:
              channelSettings.showInTeamsSearchAndSuggestions,
          },
        },
        TemplateId: templateID,
        Status: "active"
      };
      console.log("updateMSTeamsTemplate", requestBody);
      CallApiphp(
        requestBody,
        "updateMSTeamsTemplate",
        function (res: any) {
          if (res) {
            console.log(res, "response11");
          } else {
          }
        }
      );
    };
    createMSTeamsTemplatesWithChannelsTabs();
  };
  const Json_getMSTeamsTabList = () => {
    let requestBody = {
      agrno: agrno,
      Email: email,
      password: password,
    };
    CallApi(requestBody, "Json_getMSTeamsTabList", function (res: any) {
      if (res) {
        console.log(res, "Json_getMSTeamsTabList");
        let str = JSON.parse(JSON.stringify(res));
        let json = JSON.parse(str.d);
        console.log(json, "Json_getMSTeamsTabList");
        console.log(json.Table, "table1111111");
        setTabsapidata(json.Table);
      } else {
      }
    });
  };
  console.log(template, "templatecreated1", JSON.stringify(showInput.TemplateData));
  useEffect(() => {
    Json_getMSTeamsTabList();

    setTemplate(showInput);
    if (templatesettings) {
      setTemplatesettings1(templatesettings)
    }

    if (showInput && showInput.Name) {
      setGroupname(showInput.Name);
    }

    if (templatedata && templatedata.length > 0) {
      setCheckboxfeb(templatedata[0].isFavoriteByDefault ? templatedata[0].isFavoriteByDefault : false);
      setChannelname(templatedata[0].displayName);
      setChanneldes(templatedata[0].description);
    }
    // if (templatedata) {
    //     setChannels1true(templatedata[0].isFavoriteByDefault);
    //   }

    if (templatesettings) {
      setChannelSettings(prevUserDetail => ({
        ...prevUserDetail,
        allowCreateUpdateChannels: templatesettings.memberSettings.allowCreateUpdateChannels,
        allowDeleteChannels: templatesettings.memberSettings.allowDeleteChannels,
        allowAddRemoveApps: templatesettings.memberSettings.allowAddRemoveApps,
        allowCreateUpdateRemoveTabs: templatesettings.memberSettings.allowCreateUpdateRemoveTabs,
        allowCreateUpdateRemoveConnectors: templatesettings.memberSettings.allowCreateUpdateRemoveConnectors,
        allowCreateUpdateChannelsGuest: templatesettings.guestSettings.allowCreateUpdateChannelsGuest,
        allowDeleteChannelsGuest: templatesettings.guestSettings.allowDeleteChannelsGuest,
        allowDeleteChannelsFun: templatesettings.funSettings.allowDeleteChannelsFun,
        allowStickersAndMemesFun: templatesettings.funSettings
          .allowStickersAndMemesFun,
        allowCustomMemesFun: templatesettings.funSettings
          .allowCustomMemesFun,
        allowUserEditMessages: templatesettings.messagingSettings.allowUserEditMessages,
        allowUserDeleteMessages: templatesettings.messagingSettings
          .allowUserDeleteMessages,
        allowOwnerDeleteMessages: templatesettings.messagingSettings
          .allowOwnerDeleteMessages,
        allowTeamMentions: templatesettings.messagingSettings
          .allowTeamMentions,
        allowChannelMentions: templatesettings.messagingSettings
          .allowChannelMentions,
        showInTeamsSearchAndSuggestions: templatesettings.discoverySettings
          .showInTeamsSearchAndSuggestions,
      }));
    }
  }, [showInput]);
  const handleChangeTabs = (
    event: React.ChangeEvent<HTMLInputElement>,
    index: any,
    itemdata:any
  ) => {
    const isChecked = event.target.checked;
    console.log(itemdata,isChecked, "isCheckedggg", event);
    setChannels1true(event.target.checked);

    // Create a new tab object structure
    var Objt = {
      agrno: agrno,
      email: email,
      password: password,
    };

    console.log("dataStringdataString", window.btoa(JSON.stringify(Objt)));
    const newTab = {
      "teamsApp@odata.bind":
        "https://graph.microsoft.com/v1.0/appCatalogs/teamsApps/com.microsoft.teamspace.tab.web",
      displayName: event.target.name,
      configuration: {
        contentUrl: `${tabsapidata[0]?.tabs[0]?.configuration?.contentUrl}`,
      },
    };
    console.log(newTab, "newTabdata");

    
      // Push a new channel object with the tab information
      // setChannels((prevChannels:any) => [
      //   ...prevChannels,
      //   {
      //     displayName: template[0].displayName,
      //     isFavoriteByDefault: template[0].isFavoriteByDefault,
      //     description: template[0].description,
      //     tabs: [newTab],
      //   },
      // ]);
      // Assuming template is defined and contains the array of channel objects
  
  setChannels((prevChannels:any) => [
    ...prevChannels,
    {
      displayName: itemdata.displayName,
      isFavoriteByDefault: itemdata.isFavoriteByDefault,
      description: itemdata.description,
      tabs: [newTab],
    },
  ])


  };
  const handleChangeName = (event: any) => {
    setGroupname(event.target.value);
  };
  const handleChangeDescrition = (event: any) => {
    setDescription(event.target.value);
  };
  const handleChannelName = (event: any) => {
    setChannelname(event.target.value);
  };
  const handleChannelDes = (event: any) => {
    setChanneldes(event.target.value);

  };
  const handleChannecheck = (event: any) => {

    setCheckboxfeb(event.target.checked);
  };
  const additionalFields: any = [];
  const [expanded, setExpanded] = useState<string | false>(false);

  const handleChangeaccord =
    (panel: string) => (_event: React.ChangeEvent<{}>, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };

  console.log(channels, "channelschannels", channelSettings);
  const [showCreateTemplate, setShowCreateTemplate] = useState(false);
  const [showTemplateList, setShowTemplateList] = useState(false);

  const CreateTemplate = () => {
    setShowTemplateList(true);



  }
  const allowCreateUpdateChannels =
    templatesettings1 && templatesettings1.memberSettings
      ? templatesettings1.memberSettings.allowCreateUpdateChannels
      : channelSettings.allowCreateUpdateChannels;
  return (
    <div>
      {!showTemplateList && (
        <div
          className="clearfix"
          style={{ marginTop: "20px", margin: "0 auto" }}
        >

          {/* <Templatelist /> */}

          <div className="row">
            <div className="col">
              {/* <h6>Group</h6> */}
              <div style={{ marginBottom: "20px" }}>
                <TextField
                  fullWidth
                  id="standard-basic-client"
                  label="Template Name"
                  variant="outlined"
                  name="Clientname"
                  value={groupname}
                  onChange={handleChangeName}
                />
              </div>

              <div style={{ marginBottom: "20px" }}>

                <Box>
                  <h6>Advanced Setting</h6>
                  <FormGroup>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={advancedSettingChecked}
                          onChange={handleAdvancedSettingChange}
                        />
                      }
                      label="Use Default"
                    />
                    {/* <FormControlLabel
                      control={<Switch defaultChecked />}
                      label="Use Default"
                    /> */}
                  </FormGroup>
                </Box>

                <hr />

                <div style={{ marginBottom: "20px" }}>

                  {!advancedSettingChecked && (
                    <div>
                      <FormGroup>
                        <h6>Member Setting </h6>
                        <Box className="d-flex flex-wrap">
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowCreateUpdateChannels
                                }
                                onChange={handleChannelSettingChange}
                                name="allowCreateUpdateChannels"
                              />
                            }
                            label="allowCreateUpdateChannels"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowDeleteChannels
                                }
                                onChange={handleChannelSettingChange}
                                name="allowDeleteChannels"
                              />
                            }
                            label="allowDeleteChannels"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={channelSettings.allowAddRemoveApps}
                                onChange={handleChannelSettingChange}
                                name="allowAddRemoveApps"
                              />
                            }
                            label="allowAddRemoveApps"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowCreateUpdateRemoveTabs
                                }
                                onChange={handleChannelSettingChange}
                                name="allowCreateUpdateRemoveTabs"
                              />
                            }
                            label="allowCreateUpdateRemoveTabs"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowCreateUpdateRemoveConnectors
                                }
                                onChange={handleChannelSettingChange}
                                name="allowCreateUpdateRemoveConnectors"
                              />
                            }
                            label="allowCreateUpdateRemoveConnectors"
                          />
                        </Box>
                      </FormGroup>
                      <hr />


                      <FormGroup>
                        <h6>Guest Setting </h6>
                        <Box className="d-flex flex-wrap">
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowCreateUpdateChannelsGuest
                                }
                                onChange={handleChannelSettingChange}
                                name="allowCreateUpdateChannelsGuest"
                              />
                            }
                            label="allowCreateUpdateChannels"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowDeleteChannelsGuest
                                }
                                onChange={handleChannelSettingChange}
                                name="allowDeleteChannelsGuest"
                              />
                            }
                            label="allowDeleteChannels"
                          />
                        </Box>
                      </FormGroup>
                      <hr />


                      <FormGroup>
                        <h6>Fun Setting</h6>
                        <Box className="d-flex flex-wrap">
                          <FormControlLabel
                            control={<Switch />}
                            label="allowGiphy"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowDeleteChannelsFun
                                }
                                onChange={handleChannelSettingChange}
                                name="allowDeleteChannelsFun"
                              />
                            }
                            label="giphyContentRating"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowStickersAndMemesFun
                                }
                                onChange={handleChannelSettingChange}
                                name="allowStickersAndMemesFun"
                              />
                            }
                            label="allowStickersAndMemes"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowCustomMemesFun
                                }
                                onChange={handleChannelSettingChange}
                                name="allowCustomMemesFun"
                              />
                            }
                            label="allowCustomMemes"
                          />
                        </Box>
                      </FormGroup>
                      <hr />


                      <FormGroup>
                        <h6>Message Setting</h6>
                        <Box className="d-flex flex-wrap">
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowUserEditMessages
                                }
                                onChange={handleChannelSettingChange}
                                name="allowUserEditMessages"
                              />
                            }
                            label="allowUserEditMessages"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowUserDeleteMessages
                                }
                                onChange={handleChannelSettingChange}
                                name="allowUserDeleteMessages"
                              />
                            }
                            label="allowUserDeleteMessages"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowOwnerDeleteMessages
                                }
                                onChange={handleChannelSettingChange}
                                name="allowOwnerDeleteMessages"
                              />
                            }
                            label="allowOwnerDeleteMessages"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={channelSettings.allowTeamMentions}
                                onChange={handleChannelSettingChange}
                                name="allowTeamMentions"
                              />
                            }
                            label="allowTeamMentions"
                          />
                          <FormControlLabel
                            control={
                              <Switch
                                checked={
                                  channelSettings.allowChannelMentions
                                }
                                onChange={handleChannelSettingChange}
                                name="allowChannelMentions"
                              />
                            }
                            label="allowChannelMentions"
                          />
                        </Box>
                      </FormGroup>
                      <hr />

                      <FormGroup>
                        <h6>Discovery Setting</h6>
                        <FormControlLabel
                          control={
                            <Switch
                              checked={
                                channelSettings.showInTeamsSearchAndSuggestions
                              }
                              onChange={handleChannelSettingChange}
                              name="showInTeamsSearchAndSuggestions"
                            />
                          }
                          label="showInTeamsSearchAndSuggestions"
                        />
                      </FormGroup>
                      <hr />
                    </div>
                  )}
                </div>
              </div>

              <div style={{ marginBottom: "20px" }}>
                <h5 className="mb-4">Channel</h5>
                {/*  */}


                <Grid container spacing={3}>
                  <Grid item xs={6} md={6}>
                    <div style={{ marginBottom: "20px" }}>
                      <TextField
                        fullWidth
                        id={`standard-basic-client`}
                        label="Channel Name"
                        variant="outlined"
                        value={channelname}
                        onChange={(e) => handleChannelName(e)}
                        name={`Clientname`}
                      />
                    </div>
                  </Grid>

                  <Grid item xs={6} md={6}>

                    <div style={{ marginBottom: "20px" }}>
                      <FormControl fullWidth variant="outlined">
                        <TextField
                          aria-label="minimum height"
                          minRows={3}
                          name={`fullAddress`}
                          value={channeldes}
                          onChange={(e) => handleChannelDes(e)}
                          variant="outlined"
                          label="Channel Description"
                        />
                      </FormControl>
                    </div>

                  </Grid>
                </Grid>

                <Grid container spacing={3}>
                  <Grid item xs={6} md={6} className="d-flex align-items-end">
                    <div style={{ marginBottom: "20px" }}>
                      <FormGroup>
                        <FormControlLabel
                          control={
                            <Switch
                              name={`jason}`}
                              checked={checkboxfeb}
                              onChange={(e) => handleChannecheck(e)}
                            />
                          }
                          label="Favorite Channel"
                        />
                      </FormGroup>
                    </div>
                  </Grid>
                  <Grid item xs={6} md={6}>
                    <div style={{ marginBottom: "20px" }}>
                      {/* <Box sx={{ display: "flex" }}>
            <FormControl sx={{ m: 3 }} component="fieldset" variant="outlined">
              <FormLabel component="legend">Channel Tab</FormLabel>
              <FormGroup>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={channels1.gilad}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="gilad"
                    />
                  }
                  label="Client"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={channels1.jason}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="jason"
                    />
                  }
                  label="Task"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={channels1.antoine}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="antoine"
                    />
                  }
                  label="DMS"
                />
              </FormGroup>
            </FormControl>
            <FormControl
              required
              sx={{ m: 3 }}
              variant="outlined"
            ></FormControl>
             
          </Box> */}
                      <FormLabel component="legend">Channel Tab</FormLabel>
                      <FormGroup>
                      {templatedata &&
                templatedata.map((item1: any, i: any) => (
                  <div key={i}>
                    <h6>{item1?.displayName}</h6>
                    <div style={{ marginBottom: "20px" }}></div>

                    <div style={{ marginBottom: "20px" }}>
                      <FormLabel component="legend">Channel Tab</FormLabel>
                      {item1 &&
          Array.isArray(item1.tabs) &&
                        item1.tabs.map((item: any, i: any) => {
                          return (
                            <div key={i}>
                              {" "}
                              {/* Make sure to assign a unique key */}
                              {item && (
                                <FormControlLabel
                                  control={
                                    <Switch
                                      // checked={channels1true}
                                      onChange={(e) => handleChangeTabs(e, i,item1)}
                                      name={item.displayName}
                                    />
                                  }
                                  label={item.displayName}
                                />
                              )}
                            
                            </div>
                          );
                        })}
                    </div>
                    {/* {channels1true && ( 
                      <>
                        <div style={{ marginBottom: "20px" }}>
                          <TextField
                            fullWidth
                            disabled
                            id="standard-basic-client"
                            label="Project ID"
                            variant="standard"
                            name="ProjectID"
                            
                          />
                        </div>
                        <div style={{ marginBottom: "20px" }}>
                          <TextField
                            fullWidth
                            disabled
                            id="standard-basic-id"
                            label="Client ID"
                            variant="standard"
                            name="ClientID"
                        
                          />
                        </div>
                      </>
                    )} */}
                  </div>
                ))}

                        {/* <FormControlLabel
                      control={<Switch   checked={channels1.jason}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="Task"/>}
                      label="Task"
                    />

<FormControlLabel
                      control={<Switch   checked={channels1.antoine}
                      onChange={(e) => handleChangeTabs(e, i)}
                      name="DMS"/>}
                      label="DMS"
                    />
                    
                   */}
                      </FormGroup>
                    </div>
                  </Grid>
                </Grid>




                {/*  */}






              </div>
              {additionalFields}
              <div style={{ marginBottom: "20px" }}>
                <Stack spacing={2} direction="row">
                  <Button
                    variant="contained"
                    onClick={toggleAdditionalFields}
                    disabled={!groupname}
                    className="btn-blue"
                  >
                    Update Channel
                  </Button>
                  <Button variant="contained"
                    onClick={CreateTemplate}
                    className="btn-red"
                  // onClick={toggleAdditionalFields}
                  // disabled={
                  //   !groupname
                  // }
                  >
                    Cancel
                  </Button>
                  {/* <Button variant="outlined" startIcon={<DeleteIcon />}
        //  onClick={(e) => deleteChannel(e, i)}
        onClick={(e) => deleteChannel(e, i)}
        >
        Delete Channel
        </Button> */}

                  {/* <AddIcon /> */}
                </Stack>
              </div>
            </div>
          </div>






        </div>
      )}
      {showTemplateList && <Merge />}
    </div>
  );
}
